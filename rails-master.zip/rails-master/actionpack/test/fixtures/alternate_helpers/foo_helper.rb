# frozen_string_literal: true

module FooHelper
  redefine_method(:baz) {}
end
