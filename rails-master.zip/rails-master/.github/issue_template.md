### Steps to reproduce

(Guidelines for creating a bug report are [available
here](http://edgeguides.rubyonrails.org/contributing_to_ruby_on_rails.html#creating-a-bug-report))

### Expected behavior
Tell us what should happen

### Actual behavior
Tell us what happens instead

### System configuration
**Rails version**:

**Ruby version**:
