import Label from './Label';

export {Props, labelID} from './Label';
export default Label;
