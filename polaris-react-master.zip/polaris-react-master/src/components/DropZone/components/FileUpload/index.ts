import FileUpload from './FileUpload';

export {Props} from './FileUpload';
export default FileUpload;
