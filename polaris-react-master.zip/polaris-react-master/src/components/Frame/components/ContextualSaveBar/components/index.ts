export {
  default as DiscardConfirmationModal,
  Props as TDiscardConfirmationModalProps,
} from './DiscardConfirmationModal';
