import DiscardConfirmationModal from './DiscardConfirmationModal';

export {Props} from './DiscardConfirmationModal';
export default DiscardConfirmationModal;
