// This path comment acts as a unique ID
// https://github.com/Shopify/sewing-kit/issues/590
// @polaris/components/Frame/components/Loading/index.ts
import Loading from './Loading';

export {Props} from './Loading';
export default Loading;
