import ToastManager from './ToastManager';

export {Props} from './ToastManager';
export default ToastManager;
