import Frame from './Frame';

export {Props} from './Frame';
export default Frame;
