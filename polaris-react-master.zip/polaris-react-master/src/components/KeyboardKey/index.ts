import KeyboardKey from './KeyboardKey';

export {Props} from './KeyboardKey';
export default KeyboardKey;
