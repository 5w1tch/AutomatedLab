import Breadcrumbs from './Breadcrumbs';

export {Props} from './Breadcrumbs';
export default Breadcrumbs;
