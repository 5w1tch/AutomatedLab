import EmptySearchResult from './EmptySearchResult';

export {Props} from './EmptySearchResult';
export default EmptySearchResult;
