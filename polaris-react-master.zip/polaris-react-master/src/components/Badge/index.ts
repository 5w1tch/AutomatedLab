import Badge from './Badge';

export {Progress, Props, Status, PROGRESS_LABELS, STATUS_LABELS} from './Badge';
export default Badge;
