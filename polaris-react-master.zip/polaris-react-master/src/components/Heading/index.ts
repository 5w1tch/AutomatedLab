import Heading from './Heading';

export {Props} from './Heading';
export default Heading;
