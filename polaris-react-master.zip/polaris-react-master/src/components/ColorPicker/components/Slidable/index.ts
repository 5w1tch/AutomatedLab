import Slidable from './Slidable';

export {Props, Position} from './Slidable';
export default Slidable;
