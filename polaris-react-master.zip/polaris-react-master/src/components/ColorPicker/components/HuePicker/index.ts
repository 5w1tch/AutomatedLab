import HuePicker from './HuePicker';

export {Props} from './HuePicker';
export default HuePicker;
