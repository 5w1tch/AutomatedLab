import AlphaPicker from './AlphaPicker';

export {Props} from './AlphaPicker';
export default AlphaPicker;
