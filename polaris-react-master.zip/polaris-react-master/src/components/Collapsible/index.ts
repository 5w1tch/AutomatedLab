import Collapsible from './Collapsible';

export {Props} from './Collapsible';
export default Collapsible;
