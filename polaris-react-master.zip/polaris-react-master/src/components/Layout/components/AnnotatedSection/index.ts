import AnnotatedSection from './AnnotatedSection';

export {Props} from './AnnotatedSection';
export default AnnotatedSection;
