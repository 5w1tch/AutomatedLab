import Cell from './Cell';

export {Props} from './Cell';
export default Cell;
