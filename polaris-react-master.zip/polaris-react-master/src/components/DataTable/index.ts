import DataTable from './DataTable';

export {
  Props,
  TableRow,
  TableData,
  SortDirection,
  ColumnContentType,
} from './DataTable';

export default DataTable;
