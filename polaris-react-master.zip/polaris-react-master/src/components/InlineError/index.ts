import InlineError from './InlineError';

export {Props} from './InlineError';
export default InlineError;
