import EmptyState from './EmptyState';

export {Props} from './EmptyState';
export default EmptyState;
