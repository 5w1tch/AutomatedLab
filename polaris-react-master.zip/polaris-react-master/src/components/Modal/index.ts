import Modal from './Modal';

export {Props} from './Modal';
export default Modal;
