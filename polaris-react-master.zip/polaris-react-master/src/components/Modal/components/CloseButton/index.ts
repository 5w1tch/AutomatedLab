import CloseButton from './CloseButton';

export {Props as CloseButtonProps} from './CloseButton';
export default CloseButton;
