import Header from './Header';

export {Props as HeaderProps} from './Header';
export default Header;
