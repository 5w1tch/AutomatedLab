import Footer from './Footer';

export {Props as FooterProps} from './Footer';
export default Footer;
