import Section from './Section';

export {Props as SectionProps} from './Section';
export default Section;
