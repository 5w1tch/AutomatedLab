import Dialog from './Dialog';

export {Props as DialogProps} from './Dialog';
export default Dialog;
