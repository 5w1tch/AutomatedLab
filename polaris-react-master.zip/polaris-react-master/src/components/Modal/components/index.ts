export {default as Dialog, DialogProps} from './Dialog';

export {default as Footer, FooterProps} from './Footer';

export {default as Header, HeaderProps} from './Header';

export {default as CloseButton} from './CloseButton';

export {default as Section, SectionProps} from './Section';
