import Message from './Message';

export {Props} from './Message';
export default Message;
