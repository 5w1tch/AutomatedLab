import UserMenu from './UserMenu';
import * as styles from './UserMenu.scss';

export {Props} from './UserMenu';

export {styles};
export default UserMenu;
