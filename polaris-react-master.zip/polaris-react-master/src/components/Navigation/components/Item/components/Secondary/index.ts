import Secondary from './Secondary';

export default Secondary;
