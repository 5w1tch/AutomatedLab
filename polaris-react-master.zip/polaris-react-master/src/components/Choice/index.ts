import Choice from './Choice';

export {Props, helpTextID} from './Choice';
export default Choice;
