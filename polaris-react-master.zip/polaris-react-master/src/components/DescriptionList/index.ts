import DescriptionList from './DescriptionList';

export {Props} from './DescriptionList';
export default DescriptionList;
