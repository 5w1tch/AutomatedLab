import Connected from './Connected';

export {Props} from './Connected';
export default Connected;
