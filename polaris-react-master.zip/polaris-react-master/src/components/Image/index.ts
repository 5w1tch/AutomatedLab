import Image from './Image';

export {Props} from './Image';
export default Image;
