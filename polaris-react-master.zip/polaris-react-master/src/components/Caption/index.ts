import Caption from './Caption';

export {Props} from './Caption';
export default Caption;
