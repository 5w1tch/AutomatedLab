import FooterHelp from './FooterHelp';

export {Props} from './FooterHelp';
export default FooterHelp;
