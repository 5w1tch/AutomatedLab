import EventListener from './EventListener';

export {Props} from './EventListener';
export default EventListener;
