import Checkbox from './Checkbox';

export {Props} from './Checkbox';
export default Checkbox;
