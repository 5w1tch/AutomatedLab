import Header from './Header';

export {Props} from './Header';
export default Header;
