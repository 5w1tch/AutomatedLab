import Card from './Card';

export {Props} from './Card';
export default Card;
