import Link from './Link';

export {Props} from './Link';
export default Link;
