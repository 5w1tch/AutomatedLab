import MessageIndicator from './MessageIndicator';

export {Props} from './MessageIndicator';
export default MessageIndicator;
