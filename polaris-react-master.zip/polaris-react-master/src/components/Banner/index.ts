import Banner from './Banner';

export {Props, Status} from './Banner';
export default Banner;
