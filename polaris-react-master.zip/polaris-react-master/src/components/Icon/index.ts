import Icon from './Icon';

export {Props, IconSource} from './Icon';
export default Icon;
