import List from './List';

export {Props} from './List';
export default List;
