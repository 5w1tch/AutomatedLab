import Avatar from './Avatar';

export * from './Avatar';
export default Avatar;
