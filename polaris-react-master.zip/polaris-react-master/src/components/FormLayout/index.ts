import FormLayout from './FormLayout';

export {Props} from './FormLayout';
export default FormLayout;
