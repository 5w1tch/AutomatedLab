import DisplayText from './DisplayText';

export {Props} from './DisplayText';
export default DisplayText;
