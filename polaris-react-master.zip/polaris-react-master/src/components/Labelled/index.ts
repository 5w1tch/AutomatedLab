import Labelled from './Labelled';

export {Props, Action, labelID, errorID, helpTextID} from './Labelled';
export default Labelled;
