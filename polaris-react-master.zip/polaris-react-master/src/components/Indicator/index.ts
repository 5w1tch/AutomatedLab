import Indicator from './Indicator';

export {Props} from './Indicator';
export default Indicator;
