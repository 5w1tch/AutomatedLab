import Weekday from './Weekday';

export {Props} from './Weekday';
export default Weekday;
