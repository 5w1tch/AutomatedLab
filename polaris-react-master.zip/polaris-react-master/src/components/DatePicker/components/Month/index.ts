import Month from './Month';

export {Props} from './Month';
export default Month;
