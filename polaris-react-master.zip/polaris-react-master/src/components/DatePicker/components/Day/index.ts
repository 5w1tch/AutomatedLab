import Day from './Day';

export {Props} from './Day';
export default Day;
