import CalloutCard from './CalloutCard';

export {Props} from './CalloutCard';
export default CalloutCard;
