const {readmes} = require('./readmes');
const {semverRegExp} = require('./semver-reg-exp');

module.exports.readmes = readmes;
module.exports.semverRegExp = semverRegExp;
