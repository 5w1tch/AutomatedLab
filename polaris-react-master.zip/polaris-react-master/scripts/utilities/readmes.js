const readmes = Object.freeze(['README.md', 'src/components/README.md']);
module.exports.readmes = readmes;
