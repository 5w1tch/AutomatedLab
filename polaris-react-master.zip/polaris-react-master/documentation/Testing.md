# Testing

See [best practices](https://github.com/Shopify/web-foundation/tree/master/Best%20practices).
