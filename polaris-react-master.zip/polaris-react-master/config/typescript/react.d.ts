import * as React from 'react';

declare module 'react' {
  interface Attributes {
    testID?: string;
  }
}
