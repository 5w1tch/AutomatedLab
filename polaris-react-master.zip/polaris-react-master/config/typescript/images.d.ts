declare module '*.svg' {
  const image: any;
  export default image;
}

declare module '*.png' {
  const image: string;
  export default image;
}
